import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  public title = 'sample-responsive';
  public shownavbar: boolean = true;
  public paymentThrough: string = 'netBanking';

  constructor(public router: Router) {
    
  }

  public ngOnInit(): void {
    // const url: any = this.router.url();
   // console.log(url);
  }


}
