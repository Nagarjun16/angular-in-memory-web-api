import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import {ENV_CONFIG, EnvironmentConfiguration} from '../../environments/environment';


const endPoints = {
    getDetails: (config: EnvironmentConfiguration, name, password) => `${config.baseUrl}net-banking/login?userId=${name}&password=${password}`
    };

@Injectable()
export class NetBankingService {
    public config: EnvironmentConfiguration = ENV_CONFIG;
constructor(public http: HttpClient) { }

    public maptoJson(res: Response) {
      return res.json();
    }

    public getDetails(name: string, password: string): Observable<any> {
      
      return this.http.get<any>(
        endPoints.getDetails(this.config, name, password), {headers: null}
        );      
     
    }
}
