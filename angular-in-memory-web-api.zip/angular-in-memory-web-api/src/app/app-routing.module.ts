import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CardComponent } from 'src/app/card/card.component';
import { NetBankingComponent } from 'src/app/net-banking/net-banking.component';
import { WalletComponent } from 'src/app/wallet/wallet.component';

const routes: Routes = [
  { path: 'card', component: CardComponent },
  { path: 'net-banking', component: NetBankingComponent },
  { path: 'wallet', component: WalletComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
