import { Component } from '@angular/core';

@Component({
  selector: 'wallet',
  templateUrl: './wallet.component.html',
  styleUrls: ['./wallet.component.css']
})
export class WalletComponent {
  title = 'sample-responsive';
  shownavbar: boolean = true;
  paymentThrough: string = 'netBanking'; 
}
