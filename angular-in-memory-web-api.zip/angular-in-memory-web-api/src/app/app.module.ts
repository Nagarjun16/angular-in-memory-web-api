import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { ModalModule } from 'ngx-bootstrap/modal';
import { CommonModule } from '@angular/common';
import { CardComponent } from 'src/app/card/card.component';
import { NetBankingComponent } from 'src/app/net-banking/net-banking.component';
import { WalletComponent } from 'src/app/wallet/wallet.component';
import { NetBankingService } from 'src/app/services/net-banking.service';
import { HttpModule } from '@angular/http';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import {ENV_IMPORTS} from '../environments/environment';
import { FormsModule, ReactiveFormsModule  } from '@angular/forms';
import { MatDatepickerModule, MatNativeDateModule, MatFormFieldModule, MatInputModule } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
@NgModule({ 
  declarations: [
    AppComponent,WalletComponent, CardComponent,NetBankingComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CommonModule,
    HttpModule,
    HttpClientModule,
    BsDropdownModule.forRoot(),
    TooltipModule.forRoot(),
    ModalModule.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatDatepickerModule, MatNativeDateModule, MatFormFieldModule,
    MatInputModule,
    ... ENV_IMPORTS
  ],
  providers: [NetBankingService],
  bootstrap: [AppComponent]
})
export class AppModule { }
