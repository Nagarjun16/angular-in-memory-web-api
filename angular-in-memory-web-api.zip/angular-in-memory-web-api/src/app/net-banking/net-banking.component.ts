import { Component, OnInit } from '@angular/core';
import { NetBankingService } from 'src/app/services/net-banking.service';
import { FormArray, FormGroup, FormBuilder, Validators, FormControl, AbstractControl, ValidatorFn } from '@angular/forms';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import * as moment from 'moment';

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};


@Component({
  selector: 'net-banking',
  templateUrl: './net-banking.component.html',
  styleUrls: ['./net-banking.component.css']
})
export class NetBankingComponent implements OnInit {
  title = 'sample-responsive';
  shownavbar: boolean = true;
  paymentThrough: string = 'netBanking';
  events: string[] = [];
  public data: any;
  public fromDate: any = null;
  public minDate = new Date(2019, 0, 1);
  public maxDate = new Date(2020, 0, 1);

  public higlightedDate = new Date(2019, 5, 6);

  public dates: string[] = ['5/6/2019', '6/6/2019', '4/4/2019'];

  public disableDates: Date[];

  public netBankingForm: FormGroup;

  public myFilter = (d: Date): boolean => {
    const day = d.getDay();
    let mDate: any;

    // Prevent Saturday and Sunday from being selected.
    if (day !== 0 && day !== 6) {
      let matchFound: boolean = false;
      this.dates.forEach(date => {
         mDate = this.convertToDate(date);
        if (d.getDate() === mDate.getDate() && d.getMonth() === mDate.getMonth() && d.getFullYear() === mDate.getFullYear()) {
          matchFound = true;          
        } 
      });
      return !matchFound;     
    } else {
      return false;
    }
  }

  public dateClass = (d: Date): string => {
    let className: string = '';
    if (d.getDate() === this.higlightedDate.getDate() && this.checkDateRange(d, this.maxDate, this.minDate)) {
      className = 'higlight';          
    }
    return className;
  }

  public toDateFilter = (d: Date): boolean => {
    return true;

  }

  constructor(private netBankingService: NetBankingService) { }

  public ngOnInit(): void {
    this.netBankingForm = new FormGroup({
      name: new FormControl(null, []),
      password: new FormControl('', [])
    });

  }

  public fromDateChanged(event: MatDatepickerInputEvent<Date>): void {
    this.fromDate = moment(event.value);
    console.log(event.value + 'd---' + this.fromDate);

  }

  public toDateChanged(event: MatDatepickerInputEvent<Date>): void {

  }

  private checkDateRange(currentDate: Date, max: Date, min: Date): boolean {
    const cDate = moment(currentDate);
    const minDate = moment(min);
    const maxDate = moment(max);
    if (cDate > minDate && cDate <= maxDate) {
      return true;
    }
    return false;
  }

  private convertToDate(dateinString: string): Date{
    const splitedDate: string[] = dateinString.split('/');
    return new Date(parseInt(splitedDate[2]), parseInt(splitedDate[1]) - 1, parseInt(splitedDate[0]));
  }

  private getDetails(): void {
    this.netBankingService.getDetails(this.netBankingForm.controls['name'].value, this.netBankingForm.controls['password'].value).subscribe(data => {
      this.data = data;
    })

  }





}
