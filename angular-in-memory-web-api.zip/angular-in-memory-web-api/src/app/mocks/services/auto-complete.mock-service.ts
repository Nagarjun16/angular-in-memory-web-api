import { Observable } from 'rxjs/Observable';
import {MockBackend} from '../mock-backend';
import {STATUS} from 'angular-in-memory-web-api';
import {HttpHeaders, HttpResponse} from '@angular/common/http';
import {RequestParams} from '../mock-backend';

const payload = require('../data/countries-list-mock.json');

export class AutoCompleteMockService extends MockBackend {
 public static PATH: RegExp = /myStore\/api\/getContries/;
public post(params: RequestParams): Observable<HttpResponse<any>>{
return Observable.of(new HttpResponse<any>({
body: payload,
status: STATUS.OK,
headers: new HttpHeaders(),
}));
}





}
