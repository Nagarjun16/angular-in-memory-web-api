import { Observable } from 'rxjs/Observable';
import { MockBackend } from '../mock-backend';
import { STATUS } from 'angular-in-memory-web-api';
import { HttpHeaders, HttpResponse } from '@angular/common/http';
import { RequestParams } from '../mock-backend';

const payload = require('../data/net-banking-mock.json');
const failurePayload = require('../data/net-banking-mock.1.json');

export class NetBankingMockService extends MockBackend {
    public static PATH: RegExp = /net-banking\/login*/;

    public get(params: RequestParams): Observable<HttpResponse<any>> {
        let userId;
        // const userId: any = params.req.query.then((res) => {
        //     console.log(res);
        // });
       let queryString = params.req.url.split('?')[1];
       if (queryString) {
        let arr:string = queryString.split('&')[0];
        userId = arr.split('=')[1];
       }
       if (userId == '100'){
        return Observable.of(new HttpResponse<any>({
            body: payload,
            status: STATUS.OK,
            headers: new HttpHeaders(),
        }));
       }
       else {
        return Observable.of(new HttpResponse<any>({
            body: failurePayload,
            status: STATUS.OK,
            headers: new HttpHeaders(),
        }));
       }
        
    }




}
