// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.


export const environment = {
  production: false
};

export interface EnvironmentConfiguration  {
baseUrl: string;
useInmemoryBackend: boolean;
}

const env: EnvironmentConfiguration = { baseUrl: '/', useInmemoryBackend: true}

// env.baseUrl= "http://localhost:8080";


let IMPORTS: any[] = [];

IMPORTS = [
...IMPORTS
]
const memoryBackEndModule = require('angular-in-memory-web-api').HttpClientInMemoryWebApiModule;
if(env.useInmemoryBackend){
IMPORTS.push(memoryBackEndModule.forRoot(
  require('../app/mocks/in-memory-backend').InMemoryBackend,{
  apiBase: '/',
  host: env.baseUrl,
  passThruUnkownUrl: true
  }
));
}


export const ENV_IMPORTS = IMPORTS;
export const ENV_CONFIG = env;
